import { Client, GatewayIntentBits } from "discord.js";
import { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } from "@discordjs/voice";
import "dotenv/config";
import fetch from "node-fetch";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
});

client.once("ready", () => {
  console.log(`✅ Bot aktif sebagai ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  // 🔥 HELP COMMAND
  if (message.content === "!help") {
    return message.reply(`📜 **Daftar Command:**
- !chat <pesan> ➔ Chat dengan AI
- !radio ➔ Play lofi radio
- !radioindo ➔ Play radio Indonesia
- !help ➔ Menampilkan command list`);
  }

  // 🔥 AI Chat (mention bot atau !chat)
  if (message.mentions.has(client.user.id) || message.content.startsWith("!chat ")) {
    const prompt = message.content
      .replace(/<@!?(\d+)>/, "")
      .replace("!chat ", "")
      .trim();

    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
        },
        body: JSON.stringify({
          model: "meta-llama/llama-3.1-8b-instruct",
          messages: [
            {
              role: "system",
              content: "You are Kugy AI, a cute, supportive, and humble Indonesian assistant. Always reply warmly and motivatively.",
            },
            { role: "user", content: prompt },
          ],
        }),
      });

      const data = await response.json();
      const aiReply = data.choices[0].message.content;

      await message.reply({ content: `<@${message.author.id}> ${aiReply}` });
    } catch (error) {
      console.error(error);
      await message.reply("❌ Gagal menghubungi AI agent.");
    }
  }

  // 🔥 Play Lofi Radio
  if (message.content === "!radio") {
    if (!message.member.voice.channel) {
      return message.reply("❌ Kamu harus join voice channel dulu.");
    }

    const connection = joinVoiceChannel({
      channelId: message.member.voice.channel.id,
      guildId: message.guild.id,
      adapterCreator: message.guild.voiceAdapterCreator,
    });

    const player = createAudioPlayer();
    const resource = createAudioResource("https://lofi.stream.laut.fm/lofi");

    player.play(resource);
    connection.subscribe(player);

    player.on(AudioPlayerStatus.Playing, () => {
      console.log("🎧 Lofi radio is playing!");
      message.reply("✅ Memutar lofi radio sekarang!");
    });

    player.on("error", (error) => {
      console.error(error);
      message.reply("❌ Gagal memutar radio.");
    });
  }

  // 🔥 Play Radio Indonesia
  if (message.content === "!radioindo") {
    if (!message.member.voice.channel) {
      return message.reply("❌ Kamu harus join voice channel dulu.");
    }

    const connection = joinVoiceChannel({
      channelId: message.member.voice.channel.id,
      guildId: message.guild.id,
      adapterCreator: message.guild.voiceAdapterCreator,
    });

    const player = createAudioPlayer();
    const resource = createAudioResource("https://radione.top:8888/dmi");

    player.play(resource);
    connection.subscribe(player);

    player.on(AudioPlayerStatus.Playing, () => {
      console.log("🎧 Radio Indonesia is playing!");
      message.reply("✅ Memutar radio Indonesia sekarang!");
    });

    player.on("error", (error) => {
      console.error(error);
      message.reply("❌ Gagal memutar radio Indonesia.");
    });
  }

});

client.login(process.env.DISCORD_TOKEN);
